﻿// WolfgangEditor.cpp : Defines the entry point for the application.
//

#include "Main.h"

using namespace std;

int main(int argc, char* argv[])
{
	if (argc > 1)
	{
		return 1;
	}
	cout << "Hello CMake." << endl;
	return 0;
}
